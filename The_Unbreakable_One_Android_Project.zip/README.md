# The Unbreakable One — Android RPG

An offline-first Android app for the Hunter progression life-RPG.

## Included
- Offline Android app (WebView + bundled local HTML/CSS/JS)
- Local progress saving on the device
- XP, levels (500 XP per level), E/D/C/B/A/S hunter ranks
- Daily quest board and custom quest create/edit/delete
- Quest completion and gentle recovery quests
- Dungeons, boss challenges, achievements and attribute tracking
- JSON backup export and restore

## Build an installable APK with GitHub
1. Extract this ZIP.
2. Create a GitHub repository and upload **the contents** of this folder (not the ZIP itself).
3. Open the repository's **Actions** tab.
4. Select **Build Android APK** and press **Run workflow**. (It also runs after a push to `main`.)
5. When the run finishes, open it and find **Artifacts**.
6. Download `The-Unbreakable-One-APK`, extract it, then install `app-debug.apk` on your Android phone.
7. If Android asks, allow your browser/file manager to install apps from that source.

## Important
- The app works offline after installation.
- Progress is saved locally on this device. Clearing app data or uninstalling may erase it.
- Use **Settings → Export backup** regularly. Restore the JSON backup if you move phones or reinstall.
- This is a debug APK for personal use, not a Play Store release.
